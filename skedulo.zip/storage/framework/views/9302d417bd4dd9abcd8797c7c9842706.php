<?php $__env->startSection('title', 'Data Guru'); ?>

<?php $__env->startPush('page-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/datatables/datatables.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">

            <div class="page-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title">Data Guru</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
                            <li class="breadcrumb-item active">Data Guru</li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12">
                    <div class="card card-table">
                        <div class="card-body">

                            <div class="page-header">
                                <div class="row align-items-center">
                                    <div class="col">
                                        <h3 class="page-title">Informasi Guru</h3>
                                    </div>
                                    <div class="col-auto text-end float-end ms-auto download-grp">
                                        <a href="<?php echo e(route('guru-list.index')); ?>"
                                            class="btn btn-outline-gray me-2 <?php if(request()->routeIs('guru-list.index')): ?> active <?php endif; ?>"><i
                                                class="feather-list"></i></a>
                                        
                                        <a href="<?php echo e(route('guru.create')); ?>" class="btn btn-primary"><i
                                                class="fas fa-plus"></i></a>
                                    </div>
                                </div>
                            </div>

                            <?php echo $__env->yieldContent('content-guru'); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <footer>
            <p>Copyright © 2022 Dreamguys.</p>
        </footer>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-scripts'); ?>
    <script src="<?php echo e(asset('assets/plugins/datatables/datatables.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\skedulo\resources\views/admin/data-guru/index.blade.php ENDPATH**/ ?>