


<?php $__env->startSection('title', 'Hasil Jadwal'); ?>

<?php $__env->startPush('page-css'); ?>
    <link rel="stylesheet" href="assets/plugins/datatables/datatables.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">

            <div class="page-header">
                <div class="row align-items-center">
                    <div class="col">
                        <h3 class="page-title">Hasil Jadwal Belajar</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
                            <li class="breadcrumb-item active">Hasil Jadwal Belajar</li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-sm-12">
                    <div class="card card-table">
                        <div class="card-body">

                            <div class="page-header">
                                <div class="row align-items-center">
                                    <div class="col">
                                        <h3 class="page-title">Informasi Jadwal Belajar</h3>
                                    </div>
                                    <div class="col-auto text-end float-end ms-auto download-grp">
                                        <a href="<?php echo e(route('export')); ?>" class="btn btn-outline-primary me-2"><i
                                                class="fas fa-download"></i>
                                            Download</a>
                                    </div>
                                </div>
                            </div>

                            <?php if(@isset($penjadwalan)): ?>
                                <div class="table-responsive">
                                    <table
                                        class="table border-0 star-student table-hover table-center mb-0 datatable table-striped">
                                        <thead class="student-thread">
                                            <tr>
                                                <th scope="col">Jam/Hari</th>
                                                <th scope="col">7A</th>
                                                <th scope="col">7B</th>
                                                <th scope="col">7C</th>
                                                <th scope="col">8A</th>
                                                <th scope="col">8B</th>
                                                <th scope="col">8C</th>
                                                <th scope="col">9A</th>
                                                <th scope="col">9B</th>
                                                <th scope="col">9C</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <td>
                                                <?php $__currentLoopData = $waktu_belajar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $waktu_belajar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div>
                                                        <?php echo e($waktu_belajar->hari->hari); ?>,
                                                        <?php echo e($waktu_belajar->jam); ?>

                                                    </div><br>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </td>
                                            <?php for($idRuangan = 1; $idRuangan <= 9; $idRuangan++): ?>
                                                <td>
                                                    <?php $__currentLoopData = $penjadwalan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kelas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($kelas['id_ruangan'] == $idRuangan): ?>
                                                            <div>
                                                                guru:
                                                                <?php echo e($kelas->guru->nama); ?>,<br>
                                                                mapel: <?php echo e($kelas->mapel->mapel); ?>,
                                                            </div>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                            <?php endfor; ?>
                                        </tbody>
                                        
                                    </table>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <footer>
            <p>Copyright © 2022 Dreamguys.</p>
        </footer>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-scripts'); ?>
    <script src="assets/plugins/datatables/datatables.min.js"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\skedulo\resources\views/admin/penjadwalan/hasil.blade.php ENDPATH**/ ?>