<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startPush('page-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/simple-calendar/simple-calendar.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">

            <div class="page-header">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-sub-header">
                            <h3 class="page-title">Welcome <?php echo e(Auth::user()->nama); ?></h3>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                                <li class="breadcrumb-item active"><?php echo e(Auth::user()->role); ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>


            <div class="row">
                <div class="col-12 col-lg-8 col-xl-8">
                    <div class="row">
                        <div class="col-12 col-lg-12 col-xl-12 d-flex">
                            <div class="card flex-fill comman-shadow">
                                <div class="card-header">
                                    <div class="row align-items-center">
                                        <div class="col-6">
                                            <h5 class="card-title">Jadwal Mengajar</h5>
                                        </div>
                                    </div>
                                </div>
                                <div class="pt-3 pb-3">
                                    <div class="table-responsive lesson">
                                        <table class="table table-center">
                                            <tbody>
                                                <?php $__currentLoopData = $jadwal->sortBy(function ($item) {
            return $item->waktu->id_hari . $item->waktu->jam;
        }); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td>
                                                            <div class="date">
                                                                <b>Kelas <?php echo e($jadwal->ruangan->ruangan); ?></b>
                                                                <p><?php echo e($jadwal->mapel->mapel); ?></p>
                                                                <ul class="teacher-date-list">
                                                                    <li>
                                                                        <i class="fas fa-calendar-alt me-2"></i>
                                                                        <?php if($jadwal->waktu->id_hari == '1'): ?>
                                                                            Senin
                                                                        <?php elseif($jadwal->waktu->id_hari == '2'): ?>
                                                                            Selasa
                                                                        <?php elseif($jadwal->waktu->id_hari == '3'): ?>
                                                                            Rabu
                                                                        <?php elseif($jadwal->waktu->id_hari == '4'): ?>
                                                                            Kamis
                                                                        <?php elseif($jadwal->waktu->id_hari == '5'): ?>
                                                                            Jumat
                                                                        <?php endif; ?>
                                                                    </li>
                                                                    <li>|</li>
                                                                    <li>
                                                                        <i class="fas fa-clock me-2"></i>
                                                                        <?php echo e($jadwal->waktu->jam); ?>

                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </td>
                                                        <td>


                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-lg-12 col-xl-4 d-flex">
                    <div class="card flex-fill comman-shadow">
                        <div class="card-body">
                            <div id="calendar-doctor" class="calendar-container"></div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <footer>
            <p>Copyright © 2022 Dreamguys.</p>
        </footer>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-scripts'); ?>
    <script src="<?php echo e(asset('assets/plugins/simple-calendar/jquery.simple-calendar.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/calander.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/circle-progress.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\skedulo\resources\views/guru/dashboard-guru/index.blade.php ENDPATH**/ ?>