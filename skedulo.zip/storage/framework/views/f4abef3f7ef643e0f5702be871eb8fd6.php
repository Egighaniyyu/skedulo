<?php $__env->startSection('title' , 'Dashboard'); ?>

<?php $__env->startPush('page-css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?> ">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-wrapper">
    <div class="content container-fluid">

        <div class="page-header">
            <div class="row align-items-center">
                <div class="col">
                    <h3 class="page-title">Penugasan Guru</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
                        <li class="breadcrumb-item active">Teachers</li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title">Informasi Penugasan Guru</h5>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('penugasan.update', $penugasan->id)); ?>" method="POST"
                            enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label class="d-block">Guru</label>
                                        <select class="select w-100" name="id_guru" required>
                                            <option readonly selected value="<?php echo e($penugasan->id_guru); ?>">
                                                <?php echo e($penugasan->guru->nama); ?></option>
                                            <?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($guru->id); ?>"><?php echo e($guru->nama); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group ">
                                        <label class="d-block">Mata Pelajaran</label>
                                        <select class="select w-100" name="id_mapel" required>
                                            <option readonly selected value="<?php echo e($penugasan->id_mapel); ?>">
                                                <?php echo e($penugasan->mapel->mapel); ?></option>
                                            <?php $__currentLoopData = $mapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mapel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($mapel->id); ?>"><?php echo e($mapel->mapel); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group ">
                                        <label class="d-block">Kelas</label>
                                        <select class="select w-100" name="id_ruangan" required>
                                            <option readonly selected value="<?php echo e($penugasan->id_ruangan); ?>">
                                                <?php echo e($penugasan->ruangan->ruangan); ?></option>
                                            <?php $__currentLoopData = $ruangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ruangan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($ruangan->id); ?>"><?php echo e($ruangan->ruangan); ?>

                                            </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label>Porsi Jam</label>
                                        <input type="text" class="form-control" name="porsi_jam"
                                            placeholder="Masukan porsi jam" value="<?php echo e($penugasan->porsi_jam); ?>" required>
                                    </div>
                                </div>
                            </div>
                            <div class="text-end">
                                <button type="submit" class="btn btn-primary">Simpan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <footer>
        <p>Copyright © 2022 Dreamguys.</p>
    </footer>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('page-scripts'); ?>
<script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?> "></script>
<script>
    $(document).ready(function() {
        $('.select').select2();
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\skedulo\resources\views/admin/penugasan/edit.blade.php ENDPATH**/ ?>