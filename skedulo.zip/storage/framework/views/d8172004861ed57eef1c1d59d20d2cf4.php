<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="shortcut icon" href="<?php echo e(asset('assets/img/favicon.png')); ?>">
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,400;0,500;0,700;0,900;1,400;1,500;1,700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/feather/feather.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/icons/flags/flags.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome/css/fontawesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome/css/all.min.css')); ?>">
    <?php echo $__env->yieldPushContent('page-css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <style>
        .actions a .btn-del:hover {
            background-color: red !important;
            color: white !important;
        }
    </style>
</head>

<body>
    <div class="main-wrapper">
        
        <div class="header">

            <div class="header-left">
                <a href="index.html" class="logo">
                    <img src="<?php echo e(asset('assets/img/logo.png')); ?>" alt="Logo">
                </a>
                <a href="index.html" class="logo logo-small">
                    <img src="<?php echo e(asset('assets/img/logo-small.png')); ?>" alt="Logo" width="30" height="30">
                </a>
            </div>
            <div class="menu-toggle">
                <a href="javascript:void(0);" id="toggle_btn">
                    <i class="fas fa-bars"></i>
                </a>
            </div>


            <a class="mobile_btn" id="mobile_btn">
                <i class="fas fa-bars"></i>
            </a>

            <ul class="nav user-menu">

                <li class="nav-item zoom-screen me-2">
                    <a href="#" class="nav-link header-nav-list win-maximize">
                        <img src="<?php echo e(asset('assets/img/icons/header-icon-04.svg')); ?>" alt="">
                    </a>
                </li>

                <li class="nav-item dropdown has-arrow new-user-menus">
                    <a href="#" class="dropdown-toggle nav-link" data-bs-toggle="dropdown">
                        <span class="user-img">
                            <img class="rounded-circle" src="<?php echo e(asset('public/guru/' . Auth::user()->foto)); ?>"
                                width="31" alt="Soeng Souy">
                            <div class="user-text">
                                <h6><?php echo e(Auth::user()->nama); ?></h6>
                                <p class="text-muted mb-0"><?php echo e(Auth::user()->role); ?></p>
                            </div>
                        </span>
                    </a>
                    <div class="dropdown-menu">
                        <div class="user-header">
                            <div class="avatar avatar-sm">
                                <img src="<?php echo e(asset('public/guru/' . Auth::user()->foto)); ?>" alt="User Image"
                                    class="avatar-img rounded-circle">
                            </div>
                            <div class="user-text">
                                <h6><?php echo e(Auth::user()->nama); ?></h6>
                                <p class="text-muted mb-0"><?php echo e(Auth::user()->role); ?></p>
                            </div>
                        </div>
                        <form class="d-flex" action="<?php echo e(route('logout')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button class="dropdown-item" type="submit">Logout</button>
                        </form>
                    </div>
                </li>

            </ul>

        </div>
        

        
        <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        
        <?php echo $__env->yieldContent('content'); ?>
        

        
        <script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/feather.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/plugins/slimscroll/jquery.slimscroll.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/plugins/apexchart/apexcharts.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/plugins/apexchart/chart-data.js')); ?>"></script>
        <?php echo $__env->yieldPushContent('page-scripts'); ?>
        <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
        
    </div>
</body>
<?php /**PATH C:\Users\Administrator\Documents\skedulo\resources\views/layouts/master.blade.php ENDPATH**/ ?>