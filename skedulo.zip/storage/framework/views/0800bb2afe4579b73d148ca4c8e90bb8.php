<?php $__env->startSection('content-guru'); ?>
    <div class="table-responsive">
        <table class="table border-0 star-student table-hover table-center mb-0 datatable table-striped">
            <thead class="student-thread">
                <tr>
                    <th>
                        <div class="form-check check-tables">
                            <input class="form-check-input" type="checkbox" value="something">
                        </div>
                    </th>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Password</th>
                    <th>Role</th>
                    <th class="text-end">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <div class="form-check check-tables">
                                <input class="form-check-input" type="checkbox" value="something">
                            </div>
                        </td>
                        <td><?php echo e($guru->id); ?></td>
                        <td>
                            <h2 class="table-avatar">
                                <a href="#" class="avatar avatar-sm me-2"><img class="avatar-img rounded-circle"
                                        src="<?php echo e(asset('public/guru/' . $guru->foto)); ?>" alt="User Image"></a>
                                <a href="#"><?php echo e($guru->nama); ?></a>
                            </h2>
                        </td>
                        <td><?php echo e($guru->email); ?></td>
                        <td><?php echo e($guru->password); ?></td>
                        <td><?php echo e($guru->role); ?></td>
                        <td class="text-end">
                            <div class="actions">
                                <a href="<?php echo e(route('guru.edit', $guru->id)); ?>" class="btn btn-sm bg-success-light me-2">
                                    <i class="feather-edit"></i>
                                </a>
                                <form action="<?php echo e(route('guru.destroy', $guru->id)); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-sm bg-danger-light" type="submit">
                                        <i class="feather-trash-2"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.data-guru.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrator\Documents\skedulo\resources\views/admin/data-guru/guru-list.blade.php ENDPATH**/ ?>